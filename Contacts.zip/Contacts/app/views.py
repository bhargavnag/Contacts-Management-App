from django.shortcuts import render,redirect

from app.models import contactsapp, contactsform

# Create your views here.

def SignUpPage(request):
    return render(request,"app/signup.html")

def Register(request):
    print("abjhsbadj")
    if request.method =="POST":
        email = request.POST['email']
        password = request.POST['password']
        code = request.POST['code']

        user = contactsapp.objects.filter(Email=email)

        if user:
            message = "User Already Exists"
            return render(request,"app/signup.html",{'msg':message})
        else:
            newuser = contactsapp.objects.create(Email=email,Password=password,Code=code)
            return redirect("/")

def SignInPage(request):
    return render(request,"app/signin.html")

def SignInUser(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']

        user = contactsapp.objects.get(Email=email)

        if user:
            if user.Password == password:
                return redirect("/contactsform/")
            else:
                message = "Wrong Password"
                return render(request,"app/signin.html",{'msg':message})
        else:
            message = "User Not Found"
            return redirect(request,"app/signup.html",{'msg':message})


def ContactsForm(request):
    if request.method == "POST":
        name = request.POST['name']
        number = request.POST['number']
        email = request.POST['email']

        con =contactsform.objects.filter(Email=email)

        if con:
            message = "User Already Exists"
            return render(request,"app/contactsform.html",{'msg':message})
        else:
            newcon = contactsform.objects.create(Name=name,Ph_no=number,Email=email)
            all_data = contactsform.objects.all()

            return render(request,"app/contactsform.html",{'key1':all_data})
    elif request.method == 'GET':
        return render(request,"app/contactsform.html")