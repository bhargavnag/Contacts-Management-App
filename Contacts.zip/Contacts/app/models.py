from tokenize import Name
from django.db import models

# Create your models here.

class contactsapp(models.Model):
    Email = models.EmailField(max_length=150)
    Password = models.CharField(max_length=150)
    Code = models.BigIntegerField()
    
class contactsform(models.Model):
    Name = models.CharField(max_length=100)
    Ph_no = models.CharField(max_length=10)
    Email = models.EmailField(max_length=150)