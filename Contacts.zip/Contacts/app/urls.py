from django.urls import path,include
from . import views
urlpatterns = [
    path("signup/",views.SignUpPage,name="signup"),
    path("register/",views.Register,name="register"),
    path("",views.SignInPage,name="signinpage"),
    path("signin/",views.SignInUser,name="signin"),
    path("contactsform/",views.ContactsForm,name="contactsform"),
]